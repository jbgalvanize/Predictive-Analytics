##SVM Example
##http://cbio.ensmp.fr/~jvert/svn/tutorials/practical/svmbasic/svmbasic_notes.pdf
##https://www.youtube.com/watch?v=iu9rrCbSqgM

#Install Library
library(e1071)

#Create dataset
set.seed(1)
x=matrix(rnorm(20*2),ncol=2)
y=c(rep(-1,10),rep(1,10))
x[y==1,] = x[y==1,] + 1 #Takes the last 10 rows for both columns and add 1

d = data.frame(x,y=as.factor(y))
plot(x,col=(3-y)) #A look at our data that we hope to divide

#linear divider
svfit = svm(y~., data = d, kernel = 'linear', cost = 10, scale = FALSE) #Can tweak cost function, Can scale the data if you would like to standardize (if not in same units)
plot(svfit,d, ylim=c(-2,3), xlim=c(-2.3,2.5))

#Polynomial divider
svfit = svm(y~., data = d, kernel = 'polynomial', cost = 10, scale = FALSE) #Can tweak cost function, Can scale the data if you would like to standardize (if not in same units)
plot(svfit,d, ylim=c(-2,3), xlim=c(-2.3,2.5))

#Something called a sigmoid divider - doesnt look like a great choice
svfit = svm(y~., data = d, kernel = 'sigmoid', cost = 10, scale = FALSE) #Can tweak cost function, Can scale the data if you would like to standardize (if not in same units)
plot(svfit,d, ylim=c(-2,3), xlim=c(-2.3,2.5))

#We can use cross-validation to find a model that works best



#Consider, we have more data, and we would li


dat = read.table('C://Users//bernharj//Desktop//Classes I Teach//Predictive Analytics - Still To Do//Code//glmlab.txt', header = TRUE)
